<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e((isset($title) ? $title : 'Koop Hardware' )); ?></title>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      
        <?php echo $__env->yieldContent('scripts'); ?>

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <?php echo $__env->yieldContent('styles'); ?>
        
        
        <style>
            body{
                background-color: #F1F5FB;
            }
            
            .nav_links{
                text-decoration: none;
                color: #7F7F7F;
            }

            .nav_links:hover{
                text-decoration: none;
                color: #FD0302;
            }

            .nav_links.active{
                text-decoration: none;
                color: #FD0302;
                font-weight: 500;
            }
            
            .pages_nav_div .nav-item .nav-link{
                text-decoration: none;
                color: #000000;
            }

            .pages_nav_div .nav-item .nav-link:hover{
                text-decoration: none;
                color: #FD0302;
            }

            .pages_nav_div .nav-item .nav-link.active{
                text-decoration: none;
                color: #FD0302;
            }

            /* Breadcrumb link */
            .breadcrumb_col a{
                color: #FD0302;
                text-decoration: none;
            }

            /* Custom CSS */

            /* Product Name Links */
            .product-name-text{
                text-decoration: none;
                color: #000000;
                
                font-family: 'Roboto', sans-serif;
                font-weight: 400;
                font-size: 16px;
            }
            
            .product-name-text:hover{
                color: #FD0302;
                text-decoration: none;
            }

            .product-price-text{
                color: #000000;
                
                font-family: 'Roboto', sans-serif;
                font-weight: 400;
                font-size: 14px;
            }

            /* Text in Body */
            .body-text{
                font-family: 'Roboto', sans-serif;
                font-weight: 400;
                font-size:14px;
            }

            /* Text in Body Headings*/
            .heading-text{
                font-family: 'Montserrat', sans-serif;
                font-weight: 400;
                font-size: 18px;
            }

            .category-text{
                color: #FD0302;
                font-family: 'Roboto', sans-serif;
                font-weight: 400;
                font-size: 12px;
            }

            .nav-text{
                text-decoration: none;
                color: #000000;
                
                font-family: 'Roboto', sans-serif;
                font-weight: 300;
                font-size: 22px;
            }

            .nav-text.active{
                text-decoration: none;
                color: #000000;
                
                font-family: 'Roboto', sans-serif;
                font-weight: 400;
                font-size: 22px;
            }

            /* Text in Body */
            .body-text{
                font-family: 'Roboto', sans-serif;
                font-weight: 400;
                font-size: 14px;
            }

            /* Info Cards Footer */
            .body-text-thin{
                font-family: 'Roboto', sans-serif;
                font-weight: 300;
                font-size: 14px;
            }

            /* Form Label */
            .body-text-thick{
                font-family: 'Roboto', sans-serif;
                font-weight: 500;
                font-size: 14px;
            }

            /* Form Label */
            .body-text-thicker{
                font-family: 'Roboto', sans-serif;
                font-weight: 500;
                font-size: 20px;
            }

            .page-btn{
                color: white;
                background-color: #4b922d;
            }

            .page-btn:hover{
                color: white;
                background-color: #085D2A;
            }

            .page-item.active .page-link{
            background-color: #4b922d;
            border-color: #4b922d;
            }

            .dataTables_paginate li a{
                color: #4b922d;
            }

            .dataTables_paginate li a:hover{
                color: #085D2A;
            }

        </style>


        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <link rel="icon" href="/storage/logo/icon.png">
    </head>
    <body>
            
            
            <div class="container-fluid">
                <nav class="navbar navbar-expand-sm navbar-light bg-light py-0">
                    <div class="navbar-nav ml-auto register-nav">
                    </div>
                    
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->user_type === 'admin'): ?>
                                <a id="navbarDropdown" class="nav-link dropdown-toggle nav_links" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->first_name); ?>

                                </a>
                                
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">

                                    <a class="dropdown-item" href="/admin/dashboard">
                                        <?php echo e(__('Admin Dashboard')); ?>

                                    </a>

                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                        <?php else: ?>
                                <a id="navbarDropdown" class="nav-link dropdown-toggle nav_links" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->first_name); ?>

                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    
                                    <a class="dropdown-item" href="/user/dashboard">
                                        <?php echo e(__('User Dashboard')); ?>

                                    </a>
                                    
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                        <?php endif; ?>
                        
                        <?php else: ?>
                            <?php if(Route::has('login')): ?>
                                <a class="nav-link nav_links <?php echo e(Route::is('login') ? 'active' : ' '); ?>" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            <?php endif; ?>
                            <?php if(Route::has('register')): ?>
                                <a class="nav-link nav_links <?php echo e(Route::is('register') ? 'active' : ' '); ?>" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            <?php endif; ?>
                    <?php endif; ?>
                </nav> 
            </div>
            
            
            <nav class="navbar py-4 navbar-expand-md navbar-light bg-white shadow-sm">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo e(url('/store')); ?>">
                        <img src="/storage/logo/kh-logo.png" alt="Koop Hardware Logo" height="40">
                    </a>
                    
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse " id="navbarSupportedContent">
                        <!-- Left Side Of Navbar -->
                        <ul class="navbar-nav mr-auto">

                        </ul>
                        <div class="pages_nav_div">
                            <!-- Right Side Of Navbar -->
                            <ul class="navbar-nav ml-auto">
                                <!-- Authentication Links -->

                                <li class="nav-item">
                                    <a class="nav-link my-auto nav-text <?php echo e(Route::is('products.sortNameAtoZ') || Route::is('products.sortPriceHighToLow') || Route::is('products.sortPriceLowToHigh') || Route::is('products.sortNameZToA') ? 'active' : ' '); ?>" href="/store"><?php echo e(__('Store')); ?></a>
                                </li>
                                <?php if(!Auth::user()): ?>
                                    <?php elseif((Auth::user()->user_type === 'admin')): ?>
                                    <?php else: ?>
                                    <li class="nav-item ">
                                        <a class="nav-link nav-text <?php echo e(Route::is('pages.cart') || Route::is('pages.checkout') ? 'active' : ' '); ?>" href="/cart"><?php echo e(__('Cart')); ?></a>
                                    </li>
                                <?php endif; ?>
                                
                            </ul>
                        </div>
                        
                    </div>
                </div>
            </nav>  
        <div id="app">
            <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main class="container py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
            

        <?php echo $__env->yieldContent('post-scripts'); ?>
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\koophardware\resources\views/layouts/app.blade.php ENDPATH**/ ?>