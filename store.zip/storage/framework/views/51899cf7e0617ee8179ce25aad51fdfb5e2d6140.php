<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">

                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    
                    <?php if(Auth::user()->user_type === 'admin'): ?>
                        <div class="row">
                            <div class="col">
                                <a href="/products/create" class="btn btn-primary float-left">Add New Product</a>
                            </div>
                        </div>
                        
                    <?php endif; ?>

                    <h1> <?php echo e(session('user_type')); ?> </h1>
                    
                    
                    <div class="row justify-content-center">
                        <div class="col-md-6 col-md-offset-3">
                            <h4 class="text-center"> Account Info </h4>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col">
                            <table class="table table-striped">
                                <tr>
                                    <th> ID </th>
                                    <th> Name </th>
                                    <th> Email </th>
                                    <th> User Type </th>
                                </tr>
                                <tr>
                                    <th> <?php echo e($info->id); ?> </th>
                                    <th> <?php echo e($info->name); ?> </th>
                                    <th> <?php echo e($info->email); ?> </th>
                                    <th> <?php echo e($info->user_type); ?> </th>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\koophardware\resources\views/home.blade.php ENDPATH**/ ?>