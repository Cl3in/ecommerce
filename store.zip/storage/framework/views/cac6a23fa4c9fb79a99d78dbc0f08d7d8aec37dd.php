

<?php $__env->startSection('content'); ?>

    <div class="container">

        <h1> Post Product </h1>
        <?php echo Form::open(['route' => 'products.store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>


            <div class="form-group">
                <?php echo e(Form::label('product_name', 'Product Name')); ?>

                <?php echo e(Form::text('product_name', '', ['class' => 'form-control', 'placeholder' => 'Product Name'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::label('product_desc', 'Product Description')); ?>

                <?php echo e(Form::textarea('product_desc', '', ['class' => 'form-control', 'placeholder' => 'Product Description'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::label('product_price', 'Product Price')); ?>

                <?php echo e(Form::number('product_price', '', ['class' => 'form-control', 'placeholder' => 'Product Price'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::file('product_img')); ?>

            </div>

            <div class="row">
                <div class="col-xs-12 col-md-6">
                    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary mr-2'])); ?>

                    <a href="/products" class="btn btn-primary">Go Back</a>
                </div>
            </div>
        <?php echo Form::close(); ?>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\koophardware\resources\views/products/create.blade.php ENDPATH**/ ?>