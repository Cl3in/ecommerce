<?php $__env->startSection('scripts'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"/>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>

        .form-container{
            margin-top: 35px;
        }

        .forgot-pass{
            color: black;
        }

        .forgot-pass:hover{
            text-decoration: none;
        }
        
        .login-heading{
            font-family: 'Montserrat',  sans-serif ;
            font-size: 32px;
            font-weight: 500;
            color: #3490DC;
        }

        .card-header{
            background-color: #3490DC;
            color: white;
        }

        .icon-bg{
            background-color: #3490DC;
            border: none;
        }

        .input-group span i{
            color: #ffffff;
        }
        
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8 col-lg-6">
            <div class="card w-100">
                <div class="card-header body-text"><?php echo e(__('Update Account Password')); ?></div>

                <div class="card-body">

                    <div class="form-container">

                        <form method="POST" action="<?php echo e(route('password.update')); ?>">
                            <?php echo csrf_field(); ?>
    
                            <input type="hidden" name="token" value="<?php echo e($token); ?>">
    
                            <div class="form-group row justify-content-center">
                                <div class="col-md-10">
                                    <div class="input-group mb-3">
                                        <div class="input-group-append">
                                            <span class="input-group-text icon-bg"><i class="fas fa-user"> </i> </span>
                                        </div>
                                        <input id="email" type="email" class="form-control body-text <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" placeholder="Email Address" required autocomplete="email" autofocus>
        
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
    
                            <div class="form-group row justify-content-center">
                                <div class="col-md-10">
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <span class="input-group-text icon-bg"><i class="fas fa-key "> </i> </span>
                                        </div>
                                        <input id="password" type="password" class="form-control body-text <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Password" required autocomplete="new-password">
        
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
    
                            <div class="form-group row justify-content-center">
                                <div class="col-md-10">
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <span class="input-group-text icon-bg"><i class="fas fa-key "> </i> </span>
                                        </div>
                                        <input id="password-confirm" type="password" class="form-control body-text" name="password_confirmation" placeholder="Password" required autocomplete="new-password">
                                    </div>
                                </div>
                            </div>
    
                            <div class="form-group row mb-0 justify-content-center">
                                <div class="col-12 text-center">
                                    <button type="submit" class="btn btn-primary body-text">
                                        <?php echo e(__('Reset Password')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\koophardware\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>