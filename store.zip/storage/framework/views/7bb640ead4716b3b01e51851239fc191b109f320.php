

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-3 justify-content-between">
        <div class="col-6">
            <h1> <?php echo e($product->product_name); ?> </h1>
            <p> <?php echo e($product->product_description); ?> </p>
            
            
        </div>
        <div class="col-6 ">
            <div class="row mb-3">
                <div class="col">
                    <a href="/posts/<?php echo e($product->id); ?>/edit" class="btn btn-primary float-right"> <i class="far fa-edit"></i>  </a>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <?php echo Form::open(['route'=>['posts.destroy', $product->id], 'method' => 'POST']); ?>

                    <?php echo Form::hidden('_method','DELETE'); ?>

                    <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type'=>'submit','class'=>'btn btn-primary float-right' ]); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
    <hr>
    <small> Written on <?php echo e($product->created_at); ?> </small>
    <div class="row">
        <div class="col-md-12">
            <a href="/posts" class="btn btn-primary float-right">Go Back</a>
        </div>
    </div>
    
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\koophardware\resources\views/posts/show.blade.php ENDPATH**/ ?>