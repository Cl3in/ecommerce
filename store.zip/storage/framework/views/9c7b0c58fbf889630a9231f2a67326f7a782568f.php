

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-around">
        <div class="col">
            <h1> Product Posts </h1>
        </div>
        <div class="col">
            <?php if(auth()->guard()->check()): ?>
                <?php if((Auth::user()->user_type === 'admin')): ?>
                    <a href="/products/create" class="btn btn-primary float-right">Add New Product</a>
                <?php endif; ?>
            <?php endif; ?>
            
        </div>
    </div>

    <?php if(!Auth::guest()): ?>
        <h1> Current User ID: <?php echo e($current_user); ?> </h1>
    <?php endif; ?>
    
                        

    <?php if(count($products)> 0 ): ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card">
                <div class="row">
                    <div class="col-md-4 my-auto">
                        <img style="width: 100%" src="/storage/product_image/<?php echo e($product->product_image); ?>" alt="">
                    </div>
                    <div class="col-md-8 my-auto">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <h3> <a href="/products/<?php echo e($product->id); ?>"> <?php echo e($product->product_name); ?> </h3> </a>
                                <small> Written on <?php echo e($product->created_at); ?> </small> 
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>

    <?php endif; ?>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\koophardware\resources\views/products/index.blade.php ENDPATH**/ ?>