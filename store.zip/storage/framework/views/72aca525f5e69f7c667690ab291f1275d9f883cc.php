

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-3 justify-content-between">
        <div class="col-3">
            <img style="width: 100%" src="/storage/product_image/<?php echo e($product->product_image); ?>" alt="">
        </div>
        <div class="col-4 my-auto">
            <h1> <?php echo e($product->product_name); ?> </h1>
            <p> <?php echo e($product->product_description); ?> </p>
        </div>
        <div class="col-5 ">
            <div class="row justify-content-end">
                <div class="col-md-4">
                    <?php if(!Auth::guest()): ?>
                        <?php echo Form::open(['route'=>['products.destroy', $product->id], 'method' => 'POST']); ?>

                        <?php echo Form::hidden('_method','DELETE'); ?>

                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type'=>'submit','class'=>'btn btn-primary float-right mr-2' ]); ?>

                        <?php echo Form::close(); ?>

                        <a href="/products/<?php echo e($product->id); ?>/edit" class="btn btn-primary float-right mr-2"> <i class="far fa-edit"></i>  </a>
                    <?php endif; ?>
                </div>
            </div>
           
        </div>
    </div>
    <hr>
    <small> Written on <?php echo e($product->created_at); ?> </small>
    <div class="row">
        <div class="col-md-12">
            <a href="/products" class="btn btn-primary float-right">Go Back</a>
        </div>
    </div>
    
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\koophardware\resources\views/products/show.blade.php ENDPATH**/ ?>