<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

    <style>

        .card-header{
            background-color: #4b922d;
            color: white;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-md-12">
            <div class="card">
                <div class="card-header body-text"><?php echo e(__('Koop Hardware Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>" id="register_form">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">

                            <div class="col-md-5">
                                <label for="first_name" class="text-md-right body-text-thick"><?php echo e(__('First Name')); ?></label>

                                <input id="first_name" type="text" class="form-control body-text <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="First Name" name="first_name" value="<?php echo e(old('first_name')); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-5">
                                <label for="last_name" class="text-md-right body-text-thick"><?php echo e(__('Last Name')); ?></label>
                                <input id="last_name" type="text" class="form-control body-text <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Last Name" name="last_name" value="<?php echo e(old('last_name')); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-2">
                                <label for="middle_initial" class="text-md-right body-text-thick"><?php echo e(__('Middle Initial')); ?></label>
                                <input id="middle_initial" type="text" class="form-control body-text <?php $__errorArgs = ['middle_initial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Middle Initial" name="middle_initial" value="<?php echo e(old('middle_initial')); ?>" required autocomplete="name" autofocus>

                                    <?php $__errorArgs = ['middle_initial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="email" class="text-md-right body-text-thick"><?php echo e(__('E-Mail Address')); ?></label>
                                <input id="email" type="email" class="form-control body-text <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email Address" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="mobile" class="text-md-right body-text-thick"><?php echo e(__('Mobile Number')); ?></label>
                                <input id="mobile" type="text" class="form-control body-text <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Mobile Number" name="mobile" value="<?php echo e(old('mobile')); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">

                            <div class="col-md-2">
                                <label for="sex" class="text-md-right body-text-thick"><?php echo e(__('Sex')); ?></label>
                                <select id="sex" name="sex" class="form-control body-text  <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('sex')); ?>" required autocomplete="name" autofocus aria-label="">
                                        <option value=""></option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                    <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-3">
                                <label for="city" class="text-md-right body-text-thick"><?php echo e(__('City')); ?></label>
                                <select id="city" name="city" class="form-control body-text  <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('city')); ?>" required autocomplete="name" autofocus aria-label="">
                                        <option value=""></option>
                                        <option value="Batangas">Batangas</option>
                                    </select>
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-3">
                                <label for="barangay_code" class="text-md-right body-text-thick"><?php echo e(__('Barangay')); ?></label>
                                <select id="barangay_code" name="barangay_code" class="form-control body-text  <?php $__errorArgs = ['barangay_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('barangay_code')); ?>" required autocomplete="name" autofocus aria-label="">

                                    </select>
                                    <input name="barangay" id="barangay" type="hidden" value="">
                                    <?php $__errorArgs = ['barangay_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="address_notes" class="text-md-right body-text-thick"><?php echo e(__('Address Notes')); ?></label>
                                    <input id="address_notes" type="text" name="address_notes" class="form-control body-text  <?php $__errorArgs = ['address_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Address Notes / Landmark" value="<?php echo e(old('address_notes')); ?>"  autocomplete="name" autofocus aria-label="">

                                    <?php $__errorArgs = ['address_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        <div class="form-group row justify-content-center">

                            <div class="col-12 col-md-4">
                                <label for="membership_code" class="text-md-right body-text-thick"><?php echo e(__('Membership Code')); ?></label>
                                <input id="membership_code" type="text" class="form-control body-text" name="membership_code" placeholder="Membership Code (Blank if none)">
                            </div>

                            <div class="col-12 col-md-4">
                                <label for="password" class="text-md-right body-text-thick"><?php echo e(__('Password')); ?></label>
                                <input id="password" type="password" class="form-control body-text <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password" required autocomplete="new-password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="col-12 col-md-4">
                                <label for="password-confirm" class="text-md-right body-text-thick"><?php echo e(__('Confirm Password')); ?></label>
                                <input id="password-confirm" type="password" class="form-control body-text" name="password_confirmation" placeholder="Password" required autocomplete="new-password">
                            </div>

                        </div>

                        <div class="form-group row justify-content-center">
                            <div class="col-12 text-center body-text">
                                <input type="checkbox" id="agree"><span> By registering an account, I agree to Koop Hardware's <a style="text-decoration: none;" href="#">Data Privacy Policy</a></span> 
                            </div>
                        </div>

                        <div class="form-group row mb-0 justify-content-center">
                            <div class="col-6 text-right">
                                <button type="submit" class="btn page-btn ml-auto body-text" id="register_acc_btn" disabled>
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                            <div class="col-6 text-left">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn page-btn mr-auto body-text">
                                    Cancel
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('post-scripts'); ?>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.js" defer></script>
        <script type="text/javascript" src="<?php echo e(asset('js/jquery.ph-locations-v1.0.0.js')); ?>" defer></script>

        <script type="text/javascript">

            function agree_checkbox()
            {
                $('#agree').click(function () {
                    if ($(this).is(':checked')) {
                        $('#register_acc_btn').removeAttr('disabled');
                    } else {
                        $('#register_acc_btn').attr('disabled', 'disabled');
                    }
                });
            }

            function load_barangay()
            {
                $('#barangay_code').ph_locations({'location_type': 'barangays'});

                $('#city').on('change', function() {
                    if(this.value != '')
                    {
                        $('#barangay_code').ph_locations('fetch_list', [{"city_code": "041005"}]);
                    }
                    else
                    {
                        $('#barangay_code')
                        .find('option')
                        .remove()
                        .end()
                        .append('<option value=""></option>')
                        .val(''); 
                    }
                });
            }

            function set_barangay_value()
            {
                $('#register_form').submit(function(){
                    var barangay = $("#barangay_code option:selected").text();
                    document.getElementById('barangay').value = barangay;
                });
            }

            function disable_period()
            {
                $('#middle_initial').keydown(function(e) {
                    if (e.keyCode === 190 || e.keyCode === 110) {
                        e.preventDefault();
                    }
                });
            }

            $(document).ready(function(){
                agree_checkbox();
                disable_period();
                load_barangay();
                set_barangay_value();
            });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\koophardware\resources\views/auth/register.blade.php ENDPATH**/ ?>